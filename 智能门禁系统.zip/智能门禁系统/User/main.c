#include "stm32f10x.h"                  
#include "Delay.h"						
#include "OLED.h"                       
#include "KEY.h"					    
#include "Store.h"						
#include "PWM.h"
#include "buzzer.h"
#include "Encode.h"
#include "HC05.h"
#include "Serial.h"

uint8_t RxSTA = 1;
char RxData[100] = "None";

int main() {
	Key_Init_A();					    
	Key_Init_B();						
	OLED_Init();
	Store_Init();
	Buzzer_Init();
	Encode_Init();
	HC05_Init();
	PWM_Init();
//	Store_Data[1]=12345;           //可直接操作修改密码
//	Store_Save();				   //保存密码，和上同用
//	Store_Data[2]=1;			   //同理解除冻结           
//	Store_Save();					//
	int pw=12345;					//设置的密码
	int KeyNum;					        //键码
	int last;							//错误次数标志位
	int16_t Num;						//旋码数
	int Menu_Num;						//菜单旋码数
	int Last_Menu_Num = -1;				//上次菜单旋码数
	unsigned int Sum=0;                 //输入的密码
	int BTNum;							//蓝牙输入
	int password=12345;					//初始密码
	int Show_Num=40;					//OLED显示
	int Change=3;						//
	password=Store_Data[1];                     //读取flash里的密码
	last=Store_Data[2];
	int enter=1;    

//  last=1;                                    //解除冻结
	while(1) {
start:		
		Num += Encode_Get();
		KeyNum = Key_GetNum();
		if(Num >= 0){
			Menu_Num = Num%3;
		}
		else{
			Menu_Num = ((Num)%3+3)%3;
		}
		
		OLED_Clear();
		OLED_ShowChinese(0, 0 ,"一、按键输入");
		OLED_ShowChinese(0, 16,"二、蓝牙输入");
		OLED_ShowChinese(0, 32,"三、设置");
		OLED_ReverseArea(0, 16 * Menu_Num, 128, 16);
		OLED_Update();
		if(KeyNum == 8){
			switch(Menu_Num) {
				case 0:
					if(last==3) {                           //判断上次开机是否处于冻结状态
						OLED_Clear();
						OLED_ShowChinese(0, 0, "由于你失误过多了");
						OLED_ShowChinese(0, 16, "您的账号已冻结！！！");
						OLED_ShowChinese(0, 32, "请1145秒后再试");
						OLED_ShowNum(16, 32,1145141, 5, OLED_8X16);
						OLED_Update(); 
						Delay_ms(1145141);
					}
					if(enter%2==0) {                  		//密码锁上锁，不需要输入密码       
						OLED_Clear();
						OLED_ShowChinese(0, 16, "由于关闭了密码锁");
						OLED_ShowChinese(20, 32, "请进行其他选择");
						OLED_ShowChinese(60, 48, "索");																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																								OLED_Update();
						Delay_ms(2000);
						OLED_Clear();
						Show_Num=40;
						Sum=0;
						goto start;						
					}			
					OLED_Clear();
					Show_Num=40;
					while(enter%2==1&&Change!=0) {	
						OLED_ShowChinese(0, 0, "请输入密码：");				    
						OLED_ShowChinese(0, 16, "密码：");
						OLED_ShowChinese(60, 48, "嗦");							//16*16的一个关了的锁的图像
						OLED_Update();
						KeyNum=Key_GetNum();									//获取键码								
						if(KeyNum) {
							if(KeyNum==6) {						
								KeyNum=0;
							}
							if(KeyNum>=0&&KeyNum<=7) {							
								if(KeyNum>=0&&KeyNum<=6){
									Show_Num+=8; 
									Sum=Sum*10+KeyNum; 
									OLED_ShowNum(Show_Num, 16,KeyNum, 1, OLED_8X16);
								}				
								else if(KeyNum==7&&Show_Num>=40){ 
									Sum=Sum/10; 
									OLED_ShowString(Show_Num, 16, " ", OLED_8X16);
									Show_Num-=8;
								}				
								OLED_Update();
							}
							if(KeyNum==8) {										//判断密码正确性
								if(password==Sum) {                       		//如果密码正确显示 "O"      
									OLED_Clear();
									OLED_DrawCircle(63,30, 30, OLED_UNFILLED);
									OLED_DrawCircle(63,30, 29, OLED_UNFILLED);
									OLED_DrawCircle(63,30, 28, OLED_UNFILLED);
									OLED_Update();
									Delay_ms(2000);
									OLED_Clear();
									Sum=0;
									Show_Num=40;
									
									PWM_SetCompare1(2000);
									Delay_s(1);
									PWM_SetCompare1(1500);
									Delay_s(3);
									PWM_SetCompare1(2000);
									
									Sum=0;
									Change=3;
									Show_Num = 40;
									Num = 0;
									KeyNum = 0;
									Delay_ms(100);
								}else{
									Change--;
									OLED_Clear();								//如果密码错误显示 "X" 
									Buzzer_On();
								    OLED_DrawLine(0, 0, 127, 63);
									OLED_DrawLine(1, 0, 126, 62);
									OLED_DrawLine(2, 0, 125, 61);
									OLED_DrawLine(0, 63, 127, 0);
									OLED_DrawLine(1, 63, 126, 0);
									OLED_DrawLine(2, 63, 125, 0);
									OLED_Update();
									Delay_ms(1000);
									OLED_Clear();
									if(Change!=0) {
										OLED_ShowChinese(10, 30, "你还有，次机会");             
										OLED_ShowNum(60, 30,Change, 1, OLED_8X16);				
										OLED_Update();
										Delay_ms(1000);
										OLED_Clear();
									}
									if(Change==0) {
										last++;
										if(last==3) {											//冻结账号
											OLED_Clear();
											OLED_ShowChinese(0, 0, "由于你失误过多了");
											OLED_ShowChinese(0, 16, "您的账号已冻结！！！");
											OLED_ShowChinese(0, 32, "请。。。秒后再试");
											OLED_ShowNum(16, 32,11451, 5, OLED_8X16);					
											Store_Data[2]=last;								    //存入flash数组
											Store_Save();
											OLED_Update();
											Delay_ms(1145141);
										}
										OLED_Clear();
										OLED_ShowChinese(0, 16, "由于你失误太多了");
										OLED_ShowChinese(0, 32, "请稍后再试");
										OLED_ShowImage(80, 36, 16, 16,Smile);				    //显示笑脸
										OLED_Update();
										Delay_ms(5000*last);									//错误次数越多重试时间越长
										OLED_Clear();
										Change=3;
									}
								}
								Sum=0;
								Show_Num=40;
								Num = 0;
								goto start;
							}
						}
					};
					break;							
				case 1:
					if(last==3) {                           //判断上次开机是否处于冻结状态
						OLED_Clear();
						OLED_ShowChinese(0, 0, "由于你失误过多了");
						OLED_ShowChinese(0, 16, "您的账号已冻结！！！");
						OLED_ShowChinese(0, 32, "请1145秒后再试");
						OLED_ShowNum(16, 32,1145141, 5, OLED_8X16);
						OLED_Update(); 
						Delay_ms(1145141);
					}
					if(enter%2==0) {                  		//密码锁上锁，不需要输入密码       
						OLED_Clear();
						OLED_ShowChinese(0, 16, "由于关闭了密码锁");
						OLED_ShowChinese(20, 32, "请进行其他选择");
						OLED_ShowChinese(60, 48, "索");																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																								OLED_Update();
						Delay_ms(2000);
						OLED_Clear();
						Show_Num=40;
						Sum=0;
						goto start;						
					}			
					OLED_Clear();
					Show_Num=40;
					Sum = 0;
					while(enter%2==1&&Change!=0) {	
						OLED_ShowChinese(0, 0, "请输入密码：");				    
						OLED_ShowChinese(0, 16, "密码：");
						OLED_ShowChinese(60, 48, "嗦");							//16*16的一个关了的锁的图像
						OLED_Update();
						KeyNum = Key_GetNum();
						BTNum = HC05_GetInt();
						if (RxSTA == 0 && BTNum>=0&&BTNum<=6){	
							Show_Num+=8; 
							Sum=Sum*10+BTNum; 
							OLED_ShowNum(Show_Num, 16,BTNum, 1, OLED_8X16);
							OLED_Update();
							RxSTA = 1;
						}
						else if(BTNum==7&&Show_Num>=40){
							Sum=Sum/10; 
							OLED_ShowString(Show_Num, 16, " ", OLED_8X16);
							Show_Num-=8;
							OLED_Update();
							RxSTA = 1;
						}
							if(BTNum == 8){
								if(password==Sum) {                       		//如果密码正确显示 "O"      
									OLED_Clear();
									OLED_DrawCircle(63,30, 30, OLED_UNFILLED);
									OLED_DrawCircle(63,30, 29, OLED_UNFILLED);
									OLED_DrawCircle(63,30, 28, OLED_UNFILLED);
									OLED_Update();
									Delay_ms(2000);
									OLED_Clear();
									Sum=0;
									Show_Num=40;
									PWM_SetCompare1(2000);
									Delay_s(1);
									PWM_SetCompare1(1500);
									Delay_s(3);
									PWM_SetCompare1(2000);
									Sum=0;
									Change=3;
									Show_Num = 40;
									Num = 0;
									KeyNum = 0;
									Delay_ms(100);
								}else{
									Change--;
									OLED_Clear();								//如果密码错误显示 "X" 
									Buzzer_On();
									OLED_DrawLine(0, 0, 127, 63);
									OLED_DrawLine(1, 0, 126, 62);
									OLED_DrawLine(2, 0, 125, 61);
									OLED_DrawLine(0, 63, 127, 0);
									OLED_DrawLine(1, 63, 126, 0);
									OLED_DrawLine(2, 63, 125, 0);
									OLED_Update();
									Delay_ms(1000);
									OLED_Clear();
									if(Change!=0) {
										OLED_ShowChinese(10, 30, "你还有，次机会");             
										OLED_ShowNum(60, 30,Change, 1, OLED_8X16);				
										OLED_Update();
										Delay_ms(1000);
										OLED_Clear();
									}
									if(Change==0) {
										last++;
										if(last==3) {											//冻结账号
											OLED_Clear();
											OLED_ShowChinese(0, 0, "由于你失误过多了");
											OLED_ShowChinese(0, 16, "您的账号已冻结！！！");
											OLED_ShowChinese(0, 32, "请。。。秒后再试");
											OLED_ShowNum(16, 32,11451, 5, OLED_8X16);					
											Store_Data[2]=last;								    //存入flash数组
											Store_Save();
											OLED_Update();
											Delay_ms(1145141);
										}
										OLED_Clear();
										OLED_ShowChinese(0, 16, "由于你失误太多了");
										OLED_ShowChinese(0, 32, "请稍后再试");
										OLED_ShowImage(80, 36, 16, 16,Smile);				    //显示笑脸
										OLED_Update();
										Delay_ms(5000*last);									//错误次数越多重试时间越长
										OLED_Clear();
										Change=3;
									}
								}
								Sum = 0;
								BTNum = 0;
								Show_Num=40;
								Num = 0;
								OLED_Clear();
								goto start;
							}						
					}
					break;
				case 2:
					OLED_Clear();
					Show_Num=40;
					Sum=0;
					while(1){								//选择菜单								
						OLED_ShowChinese(0, 0, "请输入密码：");				    
						OLED_ShowChinese(0, 16, "密码：");
						OLED_ShowChinese(60, 48, "嗦");							//16*16的一个关了的锁的图像
						OLED_Update();							
						KeyNum=Key_GetNum();									//获取键码
						if(KeyNum) {
							if(KeyNum==6) {						
								KeyNum=0;
							}
							if(KeyNum>=0&&KeyNum<=7) {							
								if(KeyNum>=0&&KeyNum<=6){
									Show_Num+=8; 
									Sum=Sum*10+KeyNum; 
									OLED_ShowNum(Show_Num, 16,KeyNum, 1, OLED_8X16);
								}				
								else if(KeyNum==7&&Show_Num>=40){ 
									Sum=Sum/10; 
									OLED_ShowString(Show_Num, 16, " ", OLED_8X16);
									Show_Num-=8;											
								}				
								OLED_Update();
							}
							if(KeyNum==8) {										//判断密码正确性
								if(Sum==pw) {                       		//如果密码正确显示 "O"      
									OLED_Clear();
									OLED_DrawCircle(63,30, 30, OLED_UNFILLED);
									OLED_DrawCircle(63,30, 29, OLED_UNFILLED);
									OLED_DrawCircle(63,30, 28, OLED_UNFILLED);
									OLED_Update();
									Delay_ms(2000);
									OLED_Clear();
									Sum=0;
									Show_Num=40;										
									while(1) {													//设置菜单		
choose:
										Num += Encode_Get();
										KeyNum = Key_GetNum();
										if(Num >= 0){
											Menu_Num = Num%3;
										}
										else{
											Menu_Num = ((Num)%3+3)%3;
										}
										
										OLED_Clear();
										OLED_ShowChinese(0, 0 ,"一、关闭或开启密码锁");
										OLED_ShowChinese(0, 16,"二、修改密码");
										OLED_ShowChinese(0, 32,"三、保存并重置");
										OLED_ReverseArea(0, 16 * Menu_Num, 128, 16);
										OLED_Update();
											if(KeyNum == 8) {
												switch(Menu_Num) {
													case 0:												//开关密码锁
														if(enter%2==1) {								//显示关锁动画效果
															OLED_Clear();
															OLED_ShowChinese(10, 32, "嗦");
															OLED_Update();
															Delay_ms(500);
															OLED_ShowChinese(26, 32, "杠");
															OLED_Update();
															Delay_ms(500);
															OLED_ShowChinese(42, 32, "杠");
															OLED_Update();
															Delay_ms(500);
															OLED_ShowChinese(58, 32, "杠");
															OLED_Update();
															Delay_ms(500);
															OLED_ShowChinese(74, 32, "杠");
															OLED_Update();
															Delay_ms(500);
															OLED_ShowChinese(90, 32, "索");
															OLED_Update();
															Delay_ms(500);
															OLED_Clear();
															OLED_ShowChinese(10, 16,"关闭密码锁成功");
															OLED_ShowChinese(0, 32,"自动跳回设置界面");
															OLED_Update();
															Delay_ms(3000);
															OLED_Clear();																	
														}
														if(enter%2==0) {  							    //显示开锁动画效果              
															OLED_Clear();
															OLED_ShowChinese(10, 32, "索");
															OLED_Update();
															Delay_ms(500);
															OLED_ShowChinese(26, 32, "杠");
															OLED_Update();
															Delay_ms(500);
															OLED_ShowChinese(42, 32, "杠");
															OLED_Update();
															Delay_ms(500);
															OLED_ShowChinese(58, 32, "杠");
															OLED_Update();
															Delay_ms(500);
															OLED_ShowChinese(74, 32, "杠");
															OLED_Update();
															Delay_ms(500);
															OLED_ShowChinese(90, 32, "嗦");
															OLED_Update();
															Delay_ms(500);
															OLED_Clear();
															OLED_ShowChinese(10, 16,"开启密码锁成功");
															OLED_ShowChinese(0, 32,"自动跳回设置界面");
															OLED_Update();
															Delay_ms(3000);
															OLED_Clear();																	
														}
														enter++;
														goto choose;
														break;
													case 1:												  //修改密码部分
														OLED_Clear();
														while(1) {
															OLED_ShowChinese(0, 0, "请输入原密码：");
															OLED_ShowChinese(0, 16, "密码：");
															OLED_Update();
															KeyNum=Key_GetNum();
															if(KeyNum) {
																if(KeyNum==6) {						
																	KeyNum=0;
																}
																if(KeyNum>=0&&KeyNum<=7) {							
																	if(KeyNum>=0&&KeyNum<=6){
																		Show_Num+=8; 
																		Sum=Sum*10+KeyNum; 
																		OLED_ShowNum(Show_Num, 16,KeyNum, 1, OLED_8X16);
																	}				
																	else if(KeyNum==7&&Show_Num>=40){ 
																		Sum=Sum/10; 
																		OLED_ShowString(Show_Num, 16, " ", OLED_8X16);
																		Show_Num-=8;
																	}				
																	OLED_Update();
																}
																if(KeyNum==8) {
																	Show_Num=40;
																	if(Sum!=password) {					//密码不对显示×
																		OLED_Clear();
																		Buzzer_On();
																		OLED_DrawLine(0, 0, 127, 63);
																		OLED_DrawLine(1, 0, 126, 62);
																		OLED_DrawLine(2, 0, 125, 61);
																		OLED_DrawLine(0, 63, 127, 0);
																		OLED_DrawLine(1, 63, 126, 0);
																		OLED_DrawLine(2, 63, 125, 0);
																		OLED_Update();
																		Delay_ms(1000);
																		OLED_Clear();
																		Sum=0;
																		Buzzer_On();																				
																		goto start;
																		break;
																	}
																	if(Sum==password) {
																		Sum=0;
																		Show_Num=40;
																		OLED_Clear();
																		OLED_DrawCircle(63,30, 30, OLED_UNFILLED);
																		OLED_DrawCircle(63,30, 29, OLED_UNFILLED);
																		OLED_DrawCircle(63,30, 28, OLED_UNFILLED);
																		OLED_Update();
																		Delay_ms(2000);
																		OLED_Clear();
																		while(1) {
																			OLED_ShowChinese(0, 0, "请修改密码：");
																			OLED_ShowChinese(0, 16, "密码：");
																			OLED_Update();
																			KeyNum=Key_GetNum();
																			if(KeyNum) {
																				if(KeyNum==6) {
																					KeyNum=0;
																				}
																					if(KeyNum>=0&&KeyNum<=7) {							
																						if(KeyNum>=0&&KeyNum<=6){
																							Show_Num+=8; 
																							Sum=Sum*10+KeyNum; 
																							OLED_ShowNum(Show_Num, 16,KeyNum, 1, OLED_8X16);
																						}				
																						else if(KeyNum==7&&Show_Num>=40){ 
																							Sum=Sum/10; 
																							OLED_ShowString(Show_Num, 16, " ", OLED_8X16);
																							Show_Num-=8;
																						}				
																						OLED_Update();
																					}				
																					if(KeyNum==8) {
																						password=Sum;					//修改原密码保存到password
																						OLED_Clear();
																						OLED_ShowChinese(20, 0, "修改成功！");
																						OLED_ShowImage(20, 20, 60, 60,Change_lock);
																						OLED_Update();
																						Store_Data[1]=password;         //保存到闪存数组
																						Store_Save();
																						Delay_ms(2000);
																						goto start;
																					}
																			}

																		}

																	}


																}
															}


														}
														break;
							
													case 2:
														last=1;											//保存并重启则回到初始阶段
														Change=3;
														goto start;
														break;
												}


											}
										}
									}												
								if(Sum!=pw) {
									Change--;
									OLED_Clear();								//如果密码错误显示 "X" 
									Buzzer_On();
									OLED_DrawLine(0, 0, 127, 63);
									OLED_DrawLine(1, 0, 126, 62);
									OLED_DrawLine(2, 0, 125, 61);
									OLED_DrawLine(0, 63, 127, 0);
									OLED_DrawLine(1, 63, 126, 0);
									OLED_DrawLine(2, 63, 125, 0);
									OLED_Update();
									Delay_ms(1000);
									OLED_Clear();
									Sum=0;
									goto start;
								}
							}
						}
					}
			}			
		}
	}					                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               
}
