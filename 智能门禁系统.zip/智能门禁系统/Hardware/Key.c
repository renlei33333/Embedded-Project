#include "stm32f10x.h"                  // Device header
#include "Delay.h"
uint8_t KeyNum = 0;

void Key_Init_A(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);		
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);						
	
	
}
void Key_Init_B(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);		
	 
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1|GPIO_Pin_10 |GPIO_Pin_11;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);						
}

uint8_t Key_GetNum(void)
{
		if (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_6) == 1)			
	{
		Delay_ms(20);											
		while (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_6) == 1);	
		Delay_ms(20);
		KeyNum = 6;						//相当于0
	}
	
	uint8_t KeyNum = 0;
	if (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_11) == 1)			
	{
		Delay_ms(20);											
		while (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_11) == 1);	
		Delay_ms(20);											
		KeyNum = 1;												
	}
	
		if (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_10) == 1)			
	{
		Delay_ms(20);											
		while (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_10) == 1);	
		Delay_ms(20);											
		KeyNum = 2;												
	}
	
		if (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_1) == 1)			
	{
		Delay_ms(20);											
		while (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_1) == 1);	
		Delay_ms(20);											
		KeyNum = 3;												
	}
	
		if (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0) == 1)			
	{
		Delay_ms(20);											
		while (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0) == 1);	
		Delay_ms(20);											
		KeyNum = 4;												
	}
	
	if (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_7) == 1)			
	{
		Delay_ms(20);											
		while (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_7) == 1);	
		Delay_ms(20);
		KeyNum = 5;	
	}
	
	
	if (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_5) == 1)			
	{
		Delay_ms(20);											
		while (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_5) == 1);	
		Delay_ms(20);
		KeyNum = 7;	     			//密码删除键
	}
	
	if (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_4) == 1)			
	{
		Delay_ms(20);											
		while (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_4) == 1);	
		Delay_ms(20);
		KeyNum = 8;					//密码确认键
	}
		
	return KeyNum;			
}
