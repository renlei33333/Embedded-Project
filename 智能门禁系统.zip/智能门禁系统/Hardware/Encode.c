#include "stm32f10x.h"                  // Device header

int16_t Encode_Count;

void Encode_Init(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO,ENABLE);
	
	GPIO_InitTypeDef  GPIO_InitStruct;
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_13 | GPIO_Pin_14;
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStruct);
	
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOB, GPIO_PinSource13);
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOB, GPIO_PinSource14);
	
	EXTI_InitTypeDef  EXTI_InitStruct;
	EXTI_InitStruct.EXTI_Line = EXTI_Line13 | EXTI_Line14;
	EXTI_InitStruct.EXTI_LineCmd = ENABLE;
	EXTI_InitStruct.EXTI_Mode = EXTI_Mode_Interrupt;
	EXTI_InitStruct.EXTI_Trigger = EXTI_Trigger_Falling;
	EXTI_Init(&EXTI_InitStruct);
	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	
	NVIC_InitTypeDef  NVIC_InitStruct;
	NVIC_InitStruct.NVIC_IRQChannel = EXTI15_10_IRQn;
	NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 1;
	NVIC_InitStruct.NVIC_IRQChannelSubPriority  = 2;
	NVIC_Init(&NVIC_InitStruct);
}

int16_t Encode_Get(void)
{
	int16_t Temp;
	Temp = Encode_Count;
	Encode_Count = 0;
	return Temp;
}

void EXTI15_10_IRQHandler(void)
{
    static uint8_t last_A = 1, last_B = 1;  
    uint8_t current_A, current_B;
    
    if(EXTI_GetITStatus(EXTI_Line13) == SET || EXTI_GetITStatus(EXTI_Line14) == SET)
    {

        current_A = GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_13);
        current_B = GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_14);
        
        if(last_A == 1 && current_A == 0) {  
            if(current_B == 1) {
                Encode_Count--;  
            } else {
                Encode_Count++;  
            }
        }
        else if(last_B == 1 && current_B == 0) {  
            if(current_A == 1) {
                Encode_Count++;  
            } else {
                Encode_Count--;  
            }
        }
        
        last_A = current_A;
        last_B = current_B;
        
        if(EXTI_GetITStatus(EXTI_Line13) == SET)
            EXTI_ClearITPendingBit(EXTI_Line13);
        if(EXTI_GetITStatus(EXTI_Line14) == SET)
            EXTI_ClearITPendingBit(EXTI_Line14);
    }
}
