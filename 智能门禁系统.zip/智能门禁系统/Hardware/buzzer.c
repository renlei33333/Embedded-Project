#include "stm32f10x.h"                  // Device header
#include "Delay.h"

void Buzzer_Init(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructre;
	GPIO_InitStructre.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructre.GPIO_Pin = GPIO_Pin_12;			   //�޸Ķ�Ӧ�˿�ֵ
	GPIO_InitStructre.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructre);
	
	GPIO_SetBits(GPIOB, GPIO_Pin_12);
}

void Buzzer_On(void)
{
	GPIO_ResetBits(GPIOB, GPIO_Pin_12);
	Delay_ms(100);
	GPIO_ResetBits(GPIOB, GPIO_Pin_12);
	Delay_ms(100);
	GPIO_ResetBits(GPIOB, GPIO_Pin_12);
	Delay_ms(700);
	GPIO_SetBits(GPIOB, GPIO_Pin_12);
}
