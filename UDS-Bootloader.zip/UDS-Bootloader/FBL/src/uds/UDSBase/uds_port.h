

#ifndef _UDS_PORT_H_
#define _UDS_PORT_H_

#include <stdint.h>

#define FRAME_SIZE      8               // 帧长度

#define REQUEST_ID      0x511           // 请求 ID
#define FUNCTION_ID     0x7DF           // 功能 ID
#define RESPONSE_ID     0x666           // 应答 ID

#define UDS_RX_MAX      1024            // 接收缓冲区长度 --最大支持 4095 字节，可根据实际需求改动，以免资源浪费
#define UDS_TX_MAX      128             // 发送缓冲区长度 --最大支持 4095 字节，可根据实际需求改动，以免资源浪费

#define PADDING_VAL     0xAA            // 填充值，如果发送的有效数据不满一帧，则用该值填充



void uds_recv_frame(uint32_t id, uint8_t* frame_buf, uint8_t frame_dlc);



void uds_send_frame(uint32_t response_id, uint8_t* frame_buf, uint8_t frame_dlc);



void uds_init(void);



void uds_1ms_task(void);

#endif

