

#include "uds_port.h"

#include "uds_service.h"
#include "uds_tp.h"


void uds_recv_frame(uint32_t id, uint8_t* frame_buf, uint8_t frame_dlc)
{
    if(REQUEST_ID == id)
        uds_tp_recv_frame(0, frame_buf, frame_dlc);
    else if(FUNCTION_ID == id)
        uds_tp_recv_frame(1, frame_buf, frame_dlc);
    else
        ; // do nothing
}



#include "FlexCAN.h"
void uds_send_frame(uint32_t response_id, uint8_t* frame_buf, uint8_t frame_dlc)
{
    FLEXCAN0_transmit_msg(response_id, frame_buf, frame_dlc);
}



#include "SID10_SessionControl.h"
void uds_init(void)
{
    service_init();
    set_current_session(UDS_SESSION_PROG);
}



void uds_1ms_task(void)
{
    network_task();
    service_task();
}
