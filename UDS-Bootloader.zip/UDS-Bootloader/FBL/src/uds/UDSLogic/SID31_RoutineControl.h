


#ifndef _SID31_ROUTINE_CONTROL_H_
#define _SID31_ROUTINE_CONTROL_H_


#include <stdint.h>
#include "uds_type.h"



void service_31_RoutineControl(const uint8_t* msg_buf, uint16_t msg_dlc);



bool_t service_31_check_len(const uint8_t* msg_buf, uint16_t msg_dlc);

#endif


