

#include "SID37_RequestTransferExit.h"
#include "service_cfg.h"
#include "uds_service.h"




bool_t service_37_check_len(const uint8_t* msg_buf, uint16_t msg_dlc)
{
	bool_t ret = FALSE;
	
	ret = TRUE;

	return ret;
}



void service_37_RequestTransferExit(const uint8_t* msg_buf, uint16_t msg_dlc)
{
	uint8_t rsp_buf[8];

	rsp_buf[0] = USD_GET_POSITIVE_RSP(SID_37);
	uds_positive_rsp(rsp_buf, 1);
}



