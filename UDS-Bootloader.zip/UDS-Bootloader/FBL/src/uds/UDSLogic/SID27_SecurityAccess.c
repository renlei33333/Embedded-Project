

#include "SID27_SecurityAccess.h"
#include "service_cfg.h"
#include "uds_service.h"
#include <stdlib.h>

#define UNLOCKKEY					0x00000000
#define UNLOCKSEED					0x00000000
#define UNDEFINESEED				0xFFFFFFFF
#define SEEDMASK					0x80000000
#define SHIFTBIT					1
#define ALGORITHMASK				0x42303131

#define UDS_SEED_LENGTH                   (0x04)
#define UDS_REQUEST_SEED                  (0x01)
#define UDS_SEND_KEY                      (0x02)
#define UDS_FAS_MAX_TIMES                 (0x02)  

static uint8_t req_seed = 0;				// 接收到请求种子标志
static uint8_t org_seed_buf[UDS_SEED_LENGTH];


// 当前安全访问等级
static uds_sa_lv curr_sa = UDS_SA_NON;

// 安全访问种子匹配错误次数
uint8_t uds_fsa_cnt = 0;


void set_current_sa_lv(uds_sa_lv level)
{
	curr_sa = level;
}



uds_sa_lv get_current_sa_lv(void)
{
    return curr_sa;
}



volatile uint32_t mainLoopCnt;
static uint8_t rand_u8(void)
{
	static uint32_t tmp = 666;
	srand(mainLoopCnt + tmp++);
	return (rand() % 0xFF);
}



int uds_security_access(uint8_t* key_buf, uint8_t* seed_buf)
{
	uint16_t i = 0;
	for(i = 0; i < UDS_SEED_LENGTH; i++)
	{
		if(key_buf[i] != seed_buf[i] + 1) // 判断 key 是否等于 seed + 1
			return -1;
	}
	return 0;
}



bool_t service_27_check_len(const uint8_t* msg_buf, uint16_t msg_dlc)
{
	bool_t ret = FALSE;
	uint8_t subfunction;

	subfunction = UDS_GET_SUB_FUNCTION(msg_buf[1]);
	
	if ((UDS_REQUEST_SEED == subfunction && 2 == msg_dlc)
		|| (UDS_SEND_KEY == subfunction && 6 == msg_dlc))

	{
		ret = TRUE;
	}

	return ret;
}



void service_27_SecurityAccess(const uint8_t* msg_buf, uint16_t msg_dlc)
{
    uint8_t subfunction;
	uint8_t rsp_buf[8];
	uint16_t i;

	subfunction = UDS_GET_SUB_FUNCTION(msg_buf[1]);

	switch (subfunction)
	{
		case UDS_REQUEST_SEED:	// 请求种子
		{
			// 锁定时间要求不能因模块断电被清零，这里暂未实现掉电保存的功能
			if (uds_timer_chk(UDS_TIMER_FSA) > 0)
			{
				uds_negative_rsp(SID_27, NRC_REQUIRED_TIME_DELAY_NOT_EXPIRED);
				break;
			}
			req_seed = 1;
			rsp_buf[0] = USD_GET_POSITIVE_RSP(SID_27);
			rsp_buf[1] = subfunction;
			for (i = 0; i < UDS_SEED_LENGTH; i++) 
			{
				// ECU 在已经解锁的情况下，如果再次收到请求种子，则返回种子 0x00000000
				if (curr_sa == UDS_SA_LV1)
					org_seed_buf[i] = 0;
				else
				    org_seed_buf[i] = rand_u8();
				rsp_buf[2+i] = org_seed_buf[i];
			}
			uds_positive_rsp (rsp_buf, UDS_SEED_LENGTH+2);
			break;
		}
		case UDS_SEND_KEY:		// 发送密钥
		{
			// 在发送秘钥前必须先请求种子
			if (req_seed == 0)
			{
				uds_negative_rsp(SID_27, NRC_REQUEST_SEQUENCE_ERROR);
				break;
			}
			req_seed = 0;

			// 判断发送过来的密钥和自己计算的密钥是否一致
			if (!uds_security_access((uint8_t *)&msg_buf[2], org_seed_buf))
			{
				rsp_buf[0] = USD_GET_POSITIVE_RSP(SID_27);
				rsp_buf[1] = subfunction;
				uds_positive_rsp (rsp_buf,2);
				set_current_sa_lv(UDS_SA_LV1);
			}
			else
			{
				uds_fsa_cnt++;
				if (uds_fsa_cnt >= UDS_FAS_MAX_TIMES) 
				{
					// 密钥尝试次数超过限值
					uds_timer_start (UDS_TIMER_FSA); // 锁定时间要求不能因模块断电被清零，这里暂未实现掉电保存的功能
					uds_negative_rsp (SID_27, NRC_EXCEEDED_NUMBER_OF_ATTEMPTS);
				} else 
				{
					// 密钥无效
					uds_negative_rsp (SID_27, NRC_INVALID_KEY);
				}
			}
			break;
		}
		default:
			uds_negative_rsp (SID_27, NRC_SUBFUNCTION_NOT_SUPPORTED);
			break;
	}
}



