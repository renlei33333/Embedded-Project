


#ifndef _SID85_CONTROL_DTC_SETTING_H_
#define _SID85_CONTROL_DTC_SETTING_H_


#include <stdint.h>
#include "uds_type.h"


typedef enum __UDS_DTC_SETTING__
{
	UDS_DTC_SETTING_NONE = 0,
	UDS_DTC_SETTING_ON,         // 使能故障码设置
	UDS_DTC_SETTING_OFF         // 禁止故障码设置
}uds_dtc_setting;



void service_85_ControlDTCSetting(const uint8_t* msg_buf, uint16_t msg_dlc);



bool_t service_85_check_len(const uint8_t* msg_buf, uint16_t msg_dlc);


#endif


