


#ifndef _SID27_SECURITY_ACCESS_H_
#define _SID27_SECURITY_ACCESS_H_


#include <stdint.h>
#include "uds_type.h"
#include "uds_service.h"


void service_27_SecurityAccess(const uint8_t* msg_buf, uint16_t msg_dlc);



bool_t service_27_check_len(const uint8_t* msg_buf, uint16_t msg_dlc);



void set_current_sa_lv(uds_sa_lv level);



uds_sa_lv get_current_sa_lv(void);



#endif



