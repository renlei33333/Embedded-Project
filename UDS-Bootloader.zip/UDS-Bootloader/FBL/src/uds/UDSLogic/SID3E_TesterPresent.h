

#ifndef _SID2E_TEST_PRESENT_H_
#define _SID2E_TEST_PRESENT_H_

#include <stdint.h>
#include "uds_type.h"


void service_3E_TesterPresent(const uint8_t* msg_buf, uint16_t msg_dlc);



bool_t service_3E_check_len(const uint8_t* msg_buf, uint16_t msg_dlc);


#endif

