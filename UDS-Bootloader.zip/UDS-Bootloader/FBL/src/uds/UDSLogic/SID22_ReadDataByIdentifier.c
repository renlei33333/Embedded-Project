

#include "SID22_ReadDataByIdentifier.h"
#include "service_cfg.h"
#include "uds_service.h"
#include "SID10_SessionControl.h"




bool_t service_22_check_len(const uint8_t* msg_buf, uint16_t msg_dlc)
{
	bool_t ret = FALSE;
	
	(void)msg_buf;
	if(3 == msg_dlc)
		ret = TRUE;

	return ret;
}



void service_22_ReadDataByIdentifier(const uint8_t* msg_buf, uint16_t msg_dlc)
{
    uint8_t rsp_buf[128];
	uint16_t did;

    rsp_buf[0] = USD_GET_POSITIVE_RSP(SID_22);
	rsp_buf[1] = msg_buf[1];
	rsp_buf[2] = msg_buf[2];

	did = ((uint16_t)msg_buf[1]) << 8;
	did |= msg_buf[2];

	switch (did)
	{
		case 0xF186:
			rsp_buf[3] = get_current_session();
			uds_positive_rsp(rsp_buf, 4);
			break;
		
		default:
			uds_negative_rsp(SID_22, NRC_REQUEST_OUT_OF_RANGE);
			break;
	}
}



