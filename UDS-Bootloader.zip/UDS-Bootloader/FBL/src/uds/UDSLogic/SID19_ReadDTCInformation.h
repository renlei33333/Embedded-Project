


#ifndef _SID19_READ_DTC_INFORMATION_H_
#define _SID19_READ_DTC_INFORMATION_H_


#include <stdint.h>
#include "uds_type.h"



void service_19_ReadDTCInformation(const uint8_t* msg_buf, uint16_t msg_dlc);



bool_t service_19_check_len(const uint8_t* msg_buf, uint16_t msg_dlc);


#endif



