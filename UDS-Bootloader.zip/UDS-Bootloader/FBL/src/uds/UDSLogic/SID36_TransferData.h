


#ifndef _SID36_TRANSFER_DATA_H_
#define _SID36_TRANSFER_DATA_H_

#include <stdint.h>
#include "uds_type.h"



bool_t service_36_check_len(const uint8_t* msg_buf, uint16_t msg_dlc);



void service_36_TransferData(const uint8_t* msg_buf, uint16_t msg_dlc);


#endif


