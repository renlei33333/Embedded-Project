

#ifndef _SID2E_SESSION_CONTROL_H_
#define _SID2E_SESSION_CONTROL_H_

#include <stdint.h>
#include "uds_type.h"
#include "uds_service.h"


void service_10_SessionControl(const uint8_t* msg_buf, uint16_t msg_dlc);



bool_t service_10_check_len(const uint8_t* msg_buf, uint16_t msg_dlc);



void set_current_session(uds_session_t session);



uds_session_t get_current_session(void);


#endif

