


#ifndef _SID28_COMMUNICATION_CONTROL_H_
#define _SID28_COMMUNICATION_CONTROL_H_


#include <stdint.h>
#include "uds_type.h"

typedef enum __UDS_CC_MODE__
{
	UDS_CC_MODE_RX_TX = 0,	 	// 使能接收和发送
	UDS_CC_MODE_RX_NO,			// 使能接收、禁止发送
	UDS_CC_MODE_NO_TX,			// 禁止接收、使能发送
	UDS_CC_MODE_NO_NO			// 禁止接收、禁止发送
}uds_cc_mode;



void service_28_CommunicationControl(const uint8_t* msg_buf, uint16_t msg_dlc);



bool_t service_28_check_len(const uint8_t* msg_buf, uint16_t msg_dlc);


#endif



