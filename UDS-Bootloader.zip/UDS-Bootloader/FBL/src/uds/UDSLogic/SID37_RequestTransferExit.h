


#ifndef _SID37_REQUEST_TRANSFER_EXIT_H_
#define _SID37_REQUEST_TRANSFER_EXIT_H_

#include <stdint.h>
#include "uds_type.h"



bool_t service_37_check_len(const uint8_t* msg_buf, uint16_t msg_dlc);



void service_37_RequestTransferExit(const uint8_t* msg_buf, uint16_t msg_dlc);


#endif


