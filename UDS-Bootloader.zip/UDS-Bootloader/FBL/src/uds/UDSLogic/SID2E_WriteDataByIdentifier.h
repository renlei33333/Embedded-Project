

#ifndef _SID2E_WRITE_DATA_BY_IDENTIFIER_H_
#define _SID2E_WRITE_DATA_BY_IDENTIFIER_H_

#include <stdint.h>
#include "uds_type.h"


void service_2E_WriteDataByIdentifier(const uint8_t* msg_buf, uint16_t msg_dlc);



bool_t service_2E_check_len(const uint8_t* msg_buf, uint16_t msg_dlc);


#endif

