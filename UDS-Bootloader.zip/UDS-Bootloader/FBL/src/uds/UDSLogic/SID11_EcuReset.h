


#ifndef _SID11_ECU_RESET_H_
#define _SID11_ECU_RESET_H_

#include <stdint.h>
#include "uds_type.h"



bool_t service_11_check_len(const uint8_t* msg_buf, uint16_t msg_dlc);



void service_11_EcuReset(const uint8_t* msg_buf, uint16_t msg_dlc);


#endif


