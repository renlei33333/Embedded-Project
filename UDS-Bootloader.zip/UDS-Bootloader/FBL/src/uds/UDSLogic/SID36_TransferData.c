

#include "SID36_TransferData.h"
#include "service_cfg.h"
#include "uds_service.h"
#include "Flash.h"




bool_t service_36_check_len(const uint8_t* msg_buf, uint16_t msg_dlc)
{
	bool_t ret = FALSE;
	
	ret = TRUE;

	return ret;
}



void service_36_TransferData(const uint8_t* msg_buf, uint16_t msg_dlc)
{
	uint8_t rsp_buf[8];
	uint8_t bn = 0;

	bn = msg_buf[1];

	static uint32_t wrIdx = 0;
	WriteFlash(0x00014000 + wrIdx*512, 512, &msg_buf[2]);
	wrIdx++;

	rsp_buf[0] = USD_GET_POSITIVE_RSP(SID_36);
	rsp_buf[1] = bn;
	uds_positive_rsp(rsp_buf, 2);
}



