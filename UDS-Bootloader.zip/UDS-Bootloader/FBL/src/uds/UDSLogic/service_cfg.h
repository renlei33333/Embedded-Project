

#ifndef _SERVICE_CFG_H_
#define _SERVICE_CFG_H_


#define SID_NUM       16     // 当前共支持 16 个服务

#define SID_10        (0x10) 
#define SID_11        (0x11) 
#define SID_14        (0x14) 
#define SID_18        (0x18) 
#define SID_19        (0x19) 
#define SID_22        (0x22) 
#define SID_27        (0x27) 
#define SID_2E        (0x2E) 
#define SID_2F        (0x2F) 
#define SID_28        (0x28) 
#define SID_31        (0x31) 
#define SID_3E        (0x3E) 
#define SID_85        (0x85) 
#define SID_34        (0x34) 
#define SID_36        (0x36) 
#define SID_37        (0x37) 


#endif

