


#ifndef _SID34_REQUEST_DOWNLOAD_H_
#define _SID34_REQUEST_DOWNLOAD_H_

#include <stdint.h>
#include "uds_type.h"



bool_t service_34_check_len(const uint8_t* msg_buf, uint16_t msg_dlc);



void service_34_RequestDownload(const uint8_t* msg_buf, uint16_t msg_dlc);


#endif


