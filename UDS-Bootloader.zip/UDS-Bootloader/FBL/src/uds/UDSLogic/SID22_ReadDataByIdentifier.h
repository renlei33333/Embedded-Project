


#ifndef _SID22_READ_DATA_BY_IDENTIFIER_H_
#define _SID22_READ_DATA_BY_IDENTIFIER_H_


#include <stdint.h>
#include "uds_type.h"



void service_22_ReadDataByIdentifier(const uint8_t* msg_buf, uint16_t msg_dlc);


bool_t service_22_check_len(const uint8_t* msg_buf, uint16_t msg_dlc);


#endif


