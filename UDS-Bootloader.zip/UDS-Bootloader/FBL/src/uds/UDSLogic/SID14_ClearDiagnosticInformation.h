

#ifndef _SID14_CLEAR_DIAGNOSTIC_INFORMATION_H_
#define _SID14_CLEAR_DIAGNOSTIC_INFORMATION_H_


#include <stdint.h>
#include "uds_type.h"



void service_14_ClearDiagnosticInformation(const uint8_t* msg_buf, uint16_t msg_dlc);



bool_t service_14_check_len(const uint8_t* msg_buf, uint16_t msg_dlc);


#endif


